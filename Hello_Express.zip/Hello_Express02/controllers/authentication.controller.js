const userModel = require('../models/user.model');
const bcrypt = require('bcrypt');

const showLoginForm = (req, res) => {
    res.render('authentication/login');
};

const loginUser = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.render('authentication/login', { error: 'Please fill in all fields.' });
    }

    try {

        const [users] = await userModel.getUserByEmail(email);
        if (users.length === 0) {
            return res.render('authentication/login', { error: 'User not found.' });
        }

        const user = users[0];


        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.render('authentication/login', { error: 'Invalid password.' });
        }


        req.session.user = user;
        res.redirect('/user');
    } catch (err) {
        console.error('Error during login:', err);
        res.render('authentication/login', { error: 'Error during login.' });
    }
};
const logoutUser = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.status(500).send('Error logging out.');
        }
        res.redirect('/');
    });
};

module.exports = {
    showLoginForm,
    loginUser,
    logoutUser,
};