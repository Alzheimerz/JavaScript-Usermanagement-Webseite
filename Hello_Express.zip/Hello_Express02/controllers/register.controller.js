const userModel = require('../models/user.model');
const bcrypt = require('bcrypt');

const showRegisterForm = (req, res) => {
    res.render('register/registerUser');
};

const registerUser = async (req, res) => {
    const { firstName, lastName, email, password, adminCode } = req.body;


    if (!firstName || !lastName || !email || !password) {
        return res.render('register/registerUser', { error: 'Please fill in all fields.' });
    }

    if (!email.includes('@')) {
        return res.render('register/registerUser', { error: 'Invalid email address.' });
    }


    let role = 0;
    if (adminCode === "Admin") {
        role = 1;
    }

    try {

        const hashedPassword = await bcrypt.hash(password, 10);

        await userModel.createUser(firstName, lastName, email, hashedPassword, role);


        const [users] = await userModel.getUserByEmail(email);
        const user = users[0];
        req.session.user = user;

        res.redirect('/user');
    } catch (err) {
        console.error('Error during registration:', err);
        res.render('register/registerUser', { error: 'Error saving to the database.' });
    }
};

module.exports = {
    showRegisterForm,
    registerUser,
};
