const userModel = require('../models/user.model');

const showUserList = async (req, res) => {
    try {
        const [rows] = await userModel.getUsers();
        const loggedInUser = req.session.user;
        res.render('user/showUsers', {
            title: 'User',
            users: rows,
            user: loggedInUser
        });
    } catch (err) {
        console.error('Database error:', err);
        res.status(500).send('Database Error');
    }
};
const deleteUser = async (req, res) => {
    const userId = req.params.id;

    try {
        await userModel.deleteUser(userId);
        res.redirect('/user');
    } catch (err) {
        console.error('Error deleting user:', err);
        res.status(500).send('Error deleting user.');
    }
};
const showEditForm = async (req, res) => {
    const userId = req.params.id;

    try {
        const [user] = await userModel.getUserById(userId);
        res.render('user/editUser', { user: user[0] });
    } catch (err) {
        console.error('Error fetching user:', err);
        res.status(500).send('Error fetching user.');
    }
};

const updateUser = async (req, res) => {
    const userId = req.params.id;
    const { firstName, lastName, email, role } = req.body;

    try {
        await userModel.updateUser(userId, firstName, lastName, email, role);
        res.redirect('/user');
    } catch (err) {
        console.error('Error updating user:', err);
        res.status(500).send('Error updating user.');
    }
};


module.exports = {
    showUserList,
    showEditForm,
    updateUser,
    deleteUser,
};
