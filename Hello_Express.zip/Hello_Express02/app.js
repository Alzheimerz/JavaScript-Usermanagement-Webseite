const express = require('express');
const exphbs = require('express-handlebars');
const session = require('express-session');
const app = express();


const hbs = exphbs.create({
    extname: '.hbs',
    helpers: {
        eq: function (a, b) {
            return a === b;
        }
    }
});

app.engine('hbs', hbs.engine);
app.set('view engine', 'hbs');
app.set('views', './views');


app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


const indexRouter = require('./routes/index');
const userRouter = require('./routes/user.router');
const registerRouter = require('./routes/register.router');
const authenticationRouter = require('./routes/authentication.router');

app.use('/', indexRouter);
app.use('/user', userRouter);
app.use('/', registerRouter);
app.use('/', authenticationRouter);

module.exports = app;