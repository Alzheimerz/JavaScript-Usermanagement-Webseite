const pool = require('../config/db');

const getUsers = async () => {
    const query = `SELECT id, first_name, last_name, email, role FROM users ORDER BY last_name, first_name`;
    const [result] = await pool.execute(query);
    return [result];
};

const getUserByEmail = async (email) => {
    const query = `SELECT * FROM users WHERE email = ?`;
    const [result] = await pool.execute(query, [email]);
    return [result];
};

const createUser = async (firstName, lastName, email, password, role = 0) => {
    const query = `INSERT INTO users (first_name, last_name, email, password, role) VALUES (?, ?, ?, ?, ?)`;
    const values = [firstName, lastName, email, password, role];
    try {
        const [result] = await pool.execute(query, values);
        console.log('User created:', result);
        return result;
    } catch (err) {
        console.error('Database error:', err);
        throw err;
    }
};
const deleteUser = async (id) => {
    const query = `DELETE FROM users WHERE id = ?`;
    try {
        const [result] = await pool.execute(query, [id]);
        console.log('User deleted:', result);
        return result;
    } catch (err) {
        console.error('Database error:', err);
        throw err;
    }
};
const getUserById = async (id) => {
    const query = `SELECT * FROM users WHERE id = ?`;
    try {
        const [result] = await pool.execute(query, [id]);
        return [result];
    } catch (err) {
        console.error('Database error:', err);
        throw err;
    }
};

const updateUser = async (id, firstName, lastName, email, role) => {
    const query = `UPDATE users SET first_name = ?, last_name = ?, email = ?, role = ? WHERE id = ?`;
    const values = [firstName, lastName, email, role, id];
    try {
        const [result] = await pool.execute(query, values);
        console.log('User updated:', result);
        return result;
    } catch (err) {
        console.error('Database error:', err);
        throw err;
    }
};

module.exports = {
    getUsers,
    getUserByEmail,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
};
