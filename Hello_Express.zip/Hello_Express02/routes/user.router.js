const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const isAuthenticated = require('../middleware/auth');


router.get('/', isAuthenticated, userController.showUserList);
router.get('/edit/:id', isAuthenticated, userController.showEditForm);
router.post('/edit/:id', isAuthenticated, userController.updateUser);
router.post('/delete/:id', isAuthenticated, userController.deleteUser);

module.exports = router;