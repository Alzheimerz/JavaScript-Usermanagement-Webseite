const express = require('express');
const router = express.Router();
const registerController = require('../controllers/register.controller');

router.get('/register', registerController.showRegisterForm);
router.post('/register', registerController.registerUser);

module.exports = router;