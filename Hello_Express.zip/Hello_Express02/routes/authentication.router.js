const express = require('express');
const router = express.Router();
const authenticationController = require('../controllers/authentication.controller');

router.get('/login', authenticationController.showLoginForm);
router.post('/login', authenticationController.loginUser);
router.get('/logout', authenticationController.logoutUser);

module.exports = router;